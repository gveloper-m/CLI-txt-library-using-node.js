const path = require('path');
const fs = require('fs');
const prompt = require("prompt-sync")({ sigint: true });

const fileName = 'libraryData.json';
var library = [];

if (fs.existsSync(fileName)) {
    const fileData = fs.readFileSync(fileName, 'utf-8');
    library = JSON.parse(fileData);
}

let q = "none"
while(q!='read' && q!='write' && q!='add'){
    q = prompt(" read,write,add ");
}



if(q==='read'){
console.log(library);
const book = prompt("Enter bookname ");
const exists = library.includes(book);

if(exists){
    fs.readFile(path.join(__dirname, './Library', `${book}.txt`), 'utf8', (err, data) => {
        if (err) throw err;
        console.log(data);
     });
}else{
    console.log("This book doesnt exists ");
}
}else if(q==='add'){
    const NewTitle = prompt("Title Of the book: ");
    library.push(NewTitle);
    fs.writeFileSync(fileName, JSON.stringify(library));
    console.log("Library saved before exit.");

    let input = prompt("Write the text ");
    fs.appendFile(path.join(__dirname, '/library', `${NewTitle}.txt`), input , (err) => {
        if (err) throw err;
        console.log("Book written");
    });
}else {
    console.log(library);
    const EditedTitle = prompt("Title Of the book: ");
    const exists = library.includes(EditedTitle);
  
    if (exists) {
        const NewText = prompt("Write your new text: ");
        const filePath = path.join(__dirname, 'Library', `${EditedTitle}.txt`);
    
        fs.writeFile(filePath, NewText, 'utf8', (err) => {
          if (err) {
            console.error("Error writing to the file:", err);
            return;
          }
    
          console.log("Content has been written to the file.");
        });
      } else {
        console.log("This book doesn't exist.");
      }
    }
  




console.log(library);
